package gestione.prodotti;

import gestione.salvataggio.Serializzazione;
import java.util.Scanner;

public class Main
{
    public static void main (String[] args) throws java.io.IOException
    {
    Magazzino magazzino = new Magazzino();
    Serializzazione serializzazione = new Serializzazione();
    //magazzino = serializzazione.caricaMagazzino();  //carico (spero) a inizio programma

    //menu
    Scanner in = new Scanner(System.in);

    // print menu
    System.out.println("#1 aggiungi prodotti");
    System.out.println("#2 rimuovi prodotti");
    System.out.println("#3 modifica prodotti");
    System.out.println("#4 visualizza prodotti");
    System.out.println("#0 esci");

    boolean quit = false;

    int scelta;

    do {
        System.out.print("scegli un opzione: ");
        scelta = in.nextInt();

        switch (scelta) {
            case 1:
                System.out.println("hai scelto l'opzione #1");
                //comando
                break;

            case 2:
                System.out.println("hai scelto l'opzione #2");
                //comando
                break;

            case 3:
                System.out.println("hai scelto l'opzione  #3");
                // comando
                break;

            case 4:
                System.out.println("hai scelto l'opzione  #4");
                System.out.println(magazzino.toString());

                break;

            case 0:
                quit = true;
                break;

            default:

                System.out.println("scegli un numero valido");
        }

    } while (!quit);

    System.out.println("arrivederci :)");

    }
}