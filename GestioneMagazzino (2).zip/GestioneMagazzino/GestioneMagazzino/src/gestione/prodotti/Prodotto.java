package gestione.prodotti;


import java.io.Serializable;

public class Prodotto implements Serializable
{
	private String marca;
	private String modello;
	private String seriale;
	private int quantità;
	private float prezzo;
	private boolean disponibilità;
	private String descrizione_prodotto;
	private int età_minima;
	private int mesi_garanzia;
	
	public Prodotto(String marca, String modello, String seriale, int quantità, float prezzo, boolean disponibilità, String descrizione_prodotto, int età_minima, int mesi_garanzia) {
		setMarca(marca);
		setModello(modello);
		setSeriale(seriale);
		setQuantità(quantità);
		setPrezzo(prezzo);
		//setDisponibilità(disponibilità);
		setDescrizione_prodotto(descrizione_prodotto);
		setEtà_minima(età_minima);
		setMesi_garanzia(mesi_garanzia);
	}
	public Prodotto(Prodotto p1){
		setMarca(p1.getMarca());
		setModello(p1.getModello());
		setSeriale(p1.getSeriale());
		setQuantità(p1.getQuantità());
		setPrezzo(p1.getPrezzo());
		setDescrizione_prodotto(p1.getDescrizione_prodotto());
		setEtà_minima(p1.getEtà_minima());
		setMesi_garanzia(p1.getMesi_garanzia());
	}
	public String getMarca() {
		return marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	
	public String getModello() {
		return modello;
	}
	
	public void setModello(String modello) {
		this.modello = modello;
	}
	
	public String getSeriale() {
		return seriale;
	}
	
	public void setSeriale(String seriale) {
		this.seriale = seriale;
	}
	
	public int getQuantità() {
		return quantità;
	}
	
	public void setQuantità(int quantità) {
		this.quantità = quantità;
	}
	
	public float getPrezzo() {
		return prezzo;
	}
	
	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}
	
	public boolean isDisponibilità() {
		return disponibilità;
	}
	
	/*public void setDisponibilità(boolean disponibilità) {
		this.disponibilità = disponibilità;
	}*/
	
	public String getDescrizione_prodotto() {
		return descrizione_prodotto;
	}
	
	public void setDescrizione_prodotto(String descrizione_prodotto) {
		this.descrizione_prodotto = descrizione_prodotto;
	}
	
	public int getEtà_minima() {
		return età_minima;
	}
	
	public void setEtà_minima(int età_minima) {
		this.età_minima = età_minima;
	}
	
	public int getMesi_garanzia() {
		return mesi_garanzia;
	}
	
	public void setMesi_garanzia(int mesi_garanzia) {
		this.mesi_garanzia = mesi_garanzia;
	}

}
