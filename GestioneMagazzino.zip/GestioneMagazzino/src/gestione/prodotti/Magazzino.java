package gestione.prodotti;


public class Magazzino {
	private final int DIMENSIONE = 10;
	private Prodotto prodotti[];

	public Magazzino () {
		prodotti = new Prodotto [DIMENSIONE];
		
	}
	public Magazzino(Magazzino m1) {
		prodotti = new Prodotto[DIMENSIONE];
		try {
			for(int i = 0; i < DIMENSIONE; i++ ) {
				if(m1.getProdotto(i) != null)
					prodotti[i] = m1.getProdotto(i);
			}
		}
		catch(NullPointerException eccezione) {
			System.out.println("Vuoto");
		}
	}
	public Prodotto getProdotto(int posizione) {
		if(posizione>0 && posizione < DIMENSIONE)
			return prodotti[posizione];
	
	else
		return null;
	}
	public void aggiungiProdotto(Prodotto p1, int posizione) {
		try {	
			if(prodotti[posizione] == null) {
				prodotti[posizione] = new Prodotto(p1);
				System.out.println("Prodotto Aggiunto");
				
			}
			else
				System.out.println("Spazio Occupato");
		}
		catch(ArrayIndexOutOfBoundsException exception) {
			System.out.println("Posizione non valida");
		}	
	}
	public void rimuoviProdotto(Prodotto p1) {
		try {
			for(int i = 0; i < DIMENSIONE; i++)
				if(p1.getSeriale() == prodotti[i].getSeriale()){
					prodotti[i] = null;
					System.out.println("Prodotto Rimosso");
				}
				else
					System.out.println("Prodotto Non Trovato");
		}
		catch(ArrayIndexOutOfBoundsException exception) {}
		catch(NullPointerException exception) {}
	}
	
	public void modificaProdotto(Prodotto p1,Prodotto p2) {
		try {
			for(int i = 0; i < DIMENSIONE; i++)
				if(p1.getSeriale() == prodotti[i].getSeriale()){
					prodotti[i] = new Prodotto(p2);
					System.out.println("Prodotto Modificato");
				}
				else
					System.out.println("Prodotto Non Trovato");
		}
		catch(ArrayIndexOutOfBoundsException exception) {}
		catch(NullPointerException exception) {}
	}
	
}

