package gestione.prodotti;

import gestione.colori.AnsiFormat;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

import static gestione.colori.Ansi.colorize;
import static gestione.colori.Attribute.*;
public class Magazzino implements Serializable {

    private final int DIMENSIONE = 100;
    private Prodotto prodotti[];

    //colori
    AnsiFormat immettiDati = new AnsiFormat(BRIGHT_CYAN_TEXT());
    AnsiFormat corretto = new AnsiFormat(BRIGHT_GREEN_TEXT(), WHITE_BACK());
    AnsiFormat menu = new AnsiFormat(BRIGHT_BLUE_TEXT(), BOLD());
    AnsiFormat opzione = new AnsiFormat(BRIGHT_CYAN_TEXT(), BRIGHT_BLACK_BACK(), BOLD());
    AnsiFormat errore = new AnsiFormat(RED_TEXT(), BRIGHT_BLACK_BACK(), BOLD());

    /**
     * costruttore di default
     */
    public Magazzino() {
        prodotti = new Prodotto[DIMENSIONE];
    }

    /**
     * costruttore di copia
     *
     * @param m1
     */
    public Magazzino(Magazzino m1) {
        prodotti = new Prodotto[DIMENSIONE];
        try {
            for (int i = 0; i < DIMENSIONE; i++) {
                if (m1.getProdotto(i) != null)
                    prodotti[i] = m1.getProdotto(i);
            }
        } catch (NullPointerException eccezione) {
            System.out.println(colorize("Vuoto\n", errore));
        }
    }


    /**
     * Restituisce il prodotto di una posizione specifica
     *
     * @param posizione
     * @return un prodotto
     */
    public Prodotto getProdotto(int posizione) {
        if (posizione >= 0 && posizione < DIMENSIONE)
            return new Prodotto(prodotti[posizione]);

        else
            return null;
    }
    public Prodotto[] getProdotti() {
        return prodotti;
    }
    public void salvaProdotti () throws java.io.IOException{

            ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("prodotti.bin"));
            stream.writeObject(prodotti);
            stream.close();
    }

    /** deserializzazione
     * @return
     * @throws java.io.IOException
     */
    public void caricaProdotti () throws java.io.IOException{
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("prodotti.bin"));
            prodotti = (Prodotto[]) stream.readObject();
            stream.close();
        }
        catch(ClassNotFoundException  | ClassCastException e){
            System.out.println("Errore " + e.getMessage());
        }

    }

    /**
     * Restituiste la dimensione
     *
     * @return la dimensione
     */
    public int getDIMENSIONE() {
        return DIMENSIONE;
    }

    /**
     * aggiunge un prodotto nell'array dei prodotti. Stampa se lo ha aggiunto o no
     *
     * @param marca
     * @param modello
     * @param seriale
     * @param quantità
     * @param prezzo
     * @param descrizioneProdotto
     * @param etàMinima
     * @param mesiGaranzia
     * @param posizione
     */
    public void aggiungiProdotto(String marca, String modello, String seriale, int quantità, double prezzo,
                                 String descrizioneProdotto, int etàMinima, int mesiGaranzia, int posizione) {
        Prodotto p1 = new Prodotto(marca, modello, seriale, quantità, prezzo, descrizioneProdotto, etàMinima, mesiGaranzia);
        boolean trova = false;
        for (int i = 0; i < DIMENSIONE; i++) {
            try {
                if (prodotti[i].getSeriale().equals(seriale)) {
                    trova = true;
                    prodotti[i].setQuantità(prodotti[i].getQuantità() + quantità);
                    System.out.println(colorize("Quantità del prodotto aggiornata\n", corretto));
                }/* else
                    trova = false;*/

            } catch (ArrayIndexOutOfBoundsException exception) {
            } catch (NullPointerException exception) {
            }
        }
        if (!trova) {
            if (prodotti[posizione] != null)
                System.out.println(colorize("Spazio occupato\n", errore));

            else if (posizione < 0 && posizione > DIMENSIONE)
                System.out.println(colorize("Posizione non valida\n", errore));

            else {
                prodotti[posizione] = new Prodotto(p1);
                System.out.println(colorize("Prodotto aggiunto\n", corretto));
            }
        }
    }

    /**
     * aggiunge il prodotto passato per riferimento nella posizione richiesta
     *
     * @param p1
     * @param posizione
     */
    public void aggiungiProdotto(Prodotto p1, int posizione) {
        try {
            if (prodotti[posizione] != null) {
                prodotti[posizione] = new Prodotto(p1);
                System.out.println(colorize("Prodotto aggiunto\n", corretto));

            } else
                System.out.println(colorize("Spazio occupato\n", errore));
        } catch (ArrayIndexOutOfBoundsException exception) {
            System.out.println(colorize("Posizione non valida\n", errore));
        }

    }

    /**
     * rimuove il prodotto che si vuole rimuovere e stampa se lo ha rimosso o no
     *
     * @param cerca
     */
    public void rimuoviProdotto(String cerca, int quantità) {
        boolean trova = false, quantitàMetodoRimuovi = true;
        for (int i = 0; i < DIMENSIONE; i++) {
            try {
                if (prodotti[i].getSeriale().equals(cerca)) {
                    if ((prodotti[i].getQuantità() >= 1) && prodotti[i].getQuantità() > quantità) {
                        prodotti[i].setQuantità(prodotti[i].getQuantità() - quantità);
                        trova = true;
                    } else if (prodotti[i].getQuantità() < quantità) {
                        System.out.println("Impossibile eliminare più di " + prodotti[i].getQuantità() +
                                " prodotti\n");
                        //trova = false;
                        quantitàMetodoRimuovi = false;
                    } else {
                        prodotti[i] = null;
                        trova = true;
                        //quantitàMetodoRimuovi = true;
                    }
                } else
                    trova = false;
            } catch (ArrayIndexOutOfBoundsException exception) {
            } catch (NullPointerException exception) {
            }
        }
        if (trova && quantitàMetodoRimuovi)
            System.out.println(colorize("Prodotto  rimosso\n", corretto));
        else if (!trova && quantitàMetodoRimuovi)
            System.out.println(colorize("Prodotto non trovato\n", errore));
    }

	/*public void modificaProdotto(Prodotto p1,Prodotto p2)
	{
		try
		{
			for(int i = 0; i < DIMENSIONE; i++)
				if(p1.getSeriale().equals(prodotti[i].getSeriale()))
				{
					prodotti[i] = new Prodotto(p2);
					System.out.println("Prodotto Modificato");
				}
				else
					System.out.println("Prodotto Non Trovato");
		}
		catch(ArrayIndexOutOfBoundsException exception) {}
		catch(NullPointerException exception) {}
	}*/

    /**
     * modifica il prodotto che si vuole modificare, permette di cambiare 1 o più attributi. Stampa
     * se ha modificato o no
     *
     * @param cerca
     */
    public void modificaProdotto(String cerca) {
        boolean trova = false;
        for (int i = 0; i < DIMENSIONE; i++) {
            //= null;
            try {
                if (cerca.equals(prodotti[i].getSeriale())) {
                    Scanner in = new Scanner(System.in);

                    // print menu

                    boolean quit = false;

                    int scelta;
                    String clear;
                    while (!quit) {
                        System.out.println(colorize("#1 Modifica marca", menu));
                        System.out.println(colorize("#2 Modifica modello", menu));
                        System.out.println(colorize("#3 Modifica seriale", menu));
                        System.out.println(colorize("#4 Modifica quantità", menu));
                        System.out.println(colorize("#5 Modifica prezzo", menu));
                        System.out.println(colorize("#6 Modifica descrizione", menu));
                        System.out.println(colorize("#7 Modifica età minima", menu));
                        System.out.println(colorize("#8 Modifica mesi garanzia", menu));
                        System.out.println(colorize("#0 esci\n", menu));
                        System.out.println(colorize("Scegli cosa modificare: ", menu));

                        String dato = in.nextLine();
                        if (dato.equals("0") || dato.equals("1") || dato.equals("2") || dato.equals("3") ||
                                dato.equals("4") || dato.equals("5") || dato.equals("6") || dato.equals("7") || dato.equals("8"))
                            scelta = Integer.parseInt(dato);
                        else {
                            while (!(dato.equals("0") || dato.equals("1") || dato.equals("2") || dato.equals("3") ||
                                    dato.equals("4") || dato.equals("5") || dato.equals("6") || dato.equals("7") || dato.equals("8"))) {
                                //System.out.println(colorize("Hai immesso un opzione errata", menu));
                                System.out.println(colorize("Immetti nuova opzione", menu));
                                dato = in.nextLine();
                            }

                            scelta = Integer.parseInt(dato);
                        }


                        switch (scelta) {
                            case 1:
                                System.out.println(colorize("Immetti nuova marca ", immettiDati));
                                String marca = in.nextLine();
                                prodotti[i].setMarca(marca);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 2:
                                System.out.println(colorize("Immetti nuovo modello ", immettiDati));
                                String modello = in.nextLine();
                                prodotti[i].setModello(modello);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 3:
                                System.out.println(colorize("Immetti nuovo seriale ", immettiDati));
                                String seriale = in.nextLine();
                                prodotti[i].setSeriale(seriale);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 4:
                                System.out.println(colorize("Immetti nuova quantità ", immettiDati));
                                int quantità = in.nextInt();
                                while (quantità > 500) {
                                    System.out.println(colorize("Non puoi aggiungere più di 500 prodotti", immettiDati));
                                    System.out.println(colorize("Immetti quantità", immettiDati));
                                    quantità = in.nextInt();
                                }
                                prodotti[i].setQuantità(quantità);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 5:
                                System.out.println(colorize("Immetti nuovo prezzo ", immettiDati));
                                double prezzo = 0;
                                prezzo = in.nextDouble();
                                prodotti[i].setPrezzo(prezzo);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;

                            case 6:
                                System.out.println(colorize("Immetti nuova descrizione ", immettiDati));
                                String descrizioneProdotto = in.nextLine();
                                prodotti[i].setDescrizioneProdotto(descrizioneProdotto);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 7:
                                System.out.println(colorize("Immetti nuova età minima ", immettiDati));
                                int etàMinima = in.nextInt();
                                while (etàMinima >= 18) {
                                    System.out.println(colorize("Non puoi aggiungere un'età minima superiore ai 18 anni", errore));
                                    System.out.println(colorize("Immetti età minima", immettiDati));
                                    etàMinima = in.nextInt();
                                    clear = in.nextLine();
                                }
                                prodotti[i].setEtàMinima(etàMinima);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 8:
                                System.out.println(colorize("Immetti nuova garanzia ", immettiDati));
                                int mesiGaranzia = in.nextInt();
                                prodotti[i].setMesiGaranzia(mesiGaranzia);
                                System.out.println(colorize("Modifica effettuata\n", corretto));
                                break;
                            case 0:
                                quit = true;
                                break;

                            default:
                                System.out.println(colorize("Scegli un numero valido\n", errore));

                        }
                    }
                } else
                    trova = false;
            } catch (ArrayIndexOutOfBoundsException exception) {}
            catch (NullPointerException exception) {}
            catch (InputMismatchException exception) {
                System.out.println(colorize("Valore espresso in modo errato", menu));
                System.out.println(colorize("Verrai rimandato al menu modifica prodotto", menu));
                //String clear = in.nextLine();
                break;
            }

        }
        if(trova)
            System.out.println(colorize("Prodotto non trovato\n",errore));
}

    /**
     * visualizza a video il prodotto che si vuole ricercare o segnala che non
     * è stato trovato
     *
     * @param ricerca
     */
    public void visualizzaProdotto(String ricerca) {

        boolean trova = false;
        int j = 0;
        for(int i = 0; i < DIMENSIONE; i++)
        {
            try
            {
                if(prodotti[i].getSeriale().equals(ricerca))
                {
                    trova = true;
                    System.out.println("Posizione " + i + " : " + "\nMarca = " + getProdotto(i).getMarca() + " ");
                    System.out.println("Modello = " + getProdotto(i).getModello() + " ");
                    System.out.println("Seriale = " + getProdotto(i).getSeriale() + " ");
                    System.out.println("Quantità = " + getProdotto(i).getQuantità() + " ");
                    System.out.println("Prezzo = " + getProdotto(i).getPrezzo() + " Euro ");
                    System.out.println("Disponibilità = " + getProdotto(i).isDisponibilità() + " ");
                    System.out.println("Descrizione = " + getProdotto(i).getDescrizioneProdotto() + " ");
                    System.out.println("Età minima utilizzo = " + getProdotto(i).getEtàMinima() + " ");
                    System.out.println("Mesi di garanzia = " + getProdotto(i).getMesiGaranzia() + "\n");
                }
            }
            catch(NullPointerException exception) {}
            catch(ArrayIndexOutOfBoundsException exception) {}
        }
        if(!trova)
            System.out.println(colorize("Prodotto non trovato\n", errore));
}

}