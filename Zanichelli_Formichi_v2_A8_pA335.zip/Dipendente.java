
package com.company;

/* classe che rappresenta un dipendente */
class Dipendente {
    private String nome;
    private String cognome;
    private String codiceFiscale;

    /* costruttore */
    public Dipendente(String nome, String cognome, String codiceFiscale) {
        this.nome = nome;
        this.cognome = cognome;
        this.codiceFiscale = codiceFiscale;
    }
    
    /* costruttore di copia */
    public Dipendente(Dipendente dipendente) {
        this.nome = dipendente.getNome();
        this.cognome = dipendente.getCognome();
        this.codiceFiscale = dipendente.getCodiceFiscale();
    }
    
    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    @Override
    public boolean equals(Object altro) {
        if (altro == null)
            return false;
        if (altro == this)
            return true;
        if (!(altro instanceof Dipendente))
            return false;
        Dipendente altroDipendente = (Dipendente) altro;
        return altroDipendente.getCodiceFiscale().equalsIgnoreCase(this.getCodiceFiscale());
    }
}
