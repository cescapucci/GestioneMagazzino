
package com.company;

import java.util.ArrayList;
import java.util.Scanner;

/* classe che gestisce una collezione di dipendenti */
public class GestionaleDipendenti {
    private ArrayList<Dipendente> dipendenti;

    /* costruttore */
    public GestionaleDipendenti() {
        dipendenti = new ArrayList<>();
    }
    
    /* aggiunge un nuovo dipendente */
    public void nuovoDipendente(Dipendente dipendente) {
        dipendenti.add(new Dipendente(dipendente));
    }
    
    /* elimina un dipendente esistente */
    public void eliminaDipendente(Dipendente dipendente) {
        dipendenti.remove(dipendente);
    }
    
    /* restituisce numero dipendenti */
    public int numeroDipendenti() {
        return dipendenti.size();
    }
    
    /* restituisce l'elenco dei dipendenti */
    public Dipendente[] elencoDipendenti() {
        Dipendente[] array = new Dipendente[dipendenti.size()];
        return dipendenti.toArray(array);
    }

    /* main: permette l'inserimento dei dati utilizzando la tastiera */
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        GestionaleDipendenti gestionale = new GestionaleDipendenti();

        while(true) {
            System.out.println("Nome dipendente:");
            String nome = reader.next();
            System.out.println("Cognome dipendente:");
            String cognome = reader.next();
            System.out.println("Codice fiscale:");
            String codiceFiscale = reader.next();
            Dipendente dipendente = new Dipendente(nome, cognome, codiceFiscale);
            gestionale.nuovoDipendente(dipendente);
            System.out.println("[Dipendente aggiunto]");
            System.out.println("[Totale dipendenti: " + gestionale.numeroDipendenti() + "]");
        }
    }
}
