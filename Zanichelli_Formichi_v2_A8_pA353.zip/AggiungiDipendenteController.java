
package com.company;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class AggiungiDipendenteController {
    /* proprietà */
    private StringProperty nome = new SimpleStringProperty();
    private StringProperty cognome = new SimpleStringProperty();
    private StringProperty codiceFiscale = new SimpleStringProperty();
    private StringProperty messaggioValidazione = new SimpleStringProperty();

    /* riferimenti FXML */
    @FXML private TextField campoNome;
    @FXML private TextField campoCognome;
    @FXML private TextField campoCodiceFiscale;
    
    @FXML
    public void initialize() {
        // binding
        this.campoNome.textProperty().bindBidirectional(this.nome);
        this.campoCognome.textProperty().bindBidirectional(this.cognome);
        this.campoCodiceFiscale.textProperty().bindBidirectional(this.codiceFiscale);
    }

    /* getter e setter */
    public String getNome() { return nome.get(); }
    public StringProperty nomeProperty() { return nome; }
    public void setNome(String nome) { this.nome.set(nome); }
    public String getCognome() { return cognome.get(); }
    public StringProperty cognomeProperty() { return cognome; }
    public void setCognome(String cognome) { this.cognome.set(cognome); }
    public String getCodiceFiscale() { return codiceFiscale.get(); }
    public StringProperty codiceFiscaleProperty() { return codiceFiscale; }
    public void setCodiceFiscale(String codiceFiscale) { this.codiceFiscale.set(codiceFiscale); }
    public String getMessaggioValidazione() { return messaggioValidazione.get(); }
    public StringProperty messaggioValidazioneProperty() { return messaggioValidazione; }
    public void setMessaggioValidazione(String msg) { this.messaggioValidazione.set(msg); }

    /* event handler */
    public void handleAggiungiDipendente(MouseEvent event) {
        if (validaForm()) {
            // codice per aggiungere un nuovo dipendente
            // i valori da usare sono resi disponibili invocando
            // getNome(), getCognome() e getCodiceFiscale()
        }
    }
    
    private boolean validaForm() {
        boolean valido = true;
        String msg = "";
        if (getNome() == null || getNome().isEmpty()) {
            msg += "Inserisci nome\n";
            valido = false;
        }
        if (getCognome() == null || getCognome().isEmpty()) {
            msg += "Inserisci cognome\n";
            valido = false;
        }
        if (getCodiceFiscale() == null || getCodiceFiscale().isEmpty()) {
            msg += "Inserisci codice fiscale\n";
            valido = false;
        }
        setMessaggioValidazione(msg);
        return valido;
    }
}
